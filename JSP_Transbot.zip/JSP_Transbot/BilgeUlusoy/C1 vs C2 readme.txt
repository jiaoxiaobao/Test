C1: to minimize the exit time of the last job of the system;
C2: to minimize the completion time of the last job (makespan).